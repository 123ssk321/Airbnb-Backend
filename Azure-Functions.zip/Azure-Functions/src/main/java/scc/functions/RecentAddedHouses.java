package scc.functions;

import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.microsoft.azure.functions.annotation.*;

import redis.clients.jedis.Jedis;
import scc.cache.RedisCache;
import com.microsoft.azure.functions.*;
import scc.mgt.AzureProperties;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Azure Functions with Timer Trigger.
 */
public class RecentAddedHouses {
    @FunctionName("recentAddedHouses")
    public void updateMostRecentAddedHouses(@CosmosDBTrigger(name = "recentAddedHouses",
    										databaseName = "scc24db57449",
    										collectionName = "houses",
    										preferredLocations="West Europe",
    										createLeaseCollectionIfNotExists = true,
    										connectionStringSetting = "AzureCosmosDBConnection")
        							String[] houses,
        							final ExecutionContext context ) {
//		try(CosmosClient cosmosClient = new CosmosClientBuilder()
//				.endpoint(System.getenv(AzureProperties.COSMOSDB_URL))
//				.key(System.getenv(AzureProperties.COSMOSDB_KEY))
//				.directMode()
//				.connectionSharingAcrossClientsEnabled(true)
//				.contentResponseOnWriteEnabled(true)
//				.buildClient()) {
//			var db = cosmosClient.getDatabase(System.getenv(AzureProperties.COSMOSDB_DATABASE));
//
//			var users = db.getContainer(AzureProperties.USER_COSMOSDB_CONTAINER_NAME);
//			var housesc = db.getContainer(AzureProperties.HOUSE_COSMOSDB_CONTAINER_NAME);
//			var rentals = db.getContainer(AzureProperties.RENTAL_COSMOSDB_CONTAINER_NAME);
//			var questions = db.getContainer(AzureProperties.QUESTION_COSMOSDB_CONTAINER_NAME);
//
//			BlobContainerClient userBlobContainer = new BlobContainerClientBuilder()
//					.connectionString(System.getenv(AzureProperties.BLOB_KEY))
//					.containerName(AzureProperties.USER_BLOB_CONTAINER_NAME)
//					.buildClient();
//
//			BlobContainerClient houseBlobContainer = new BlobContainerClientBuilder()
//					.connectionString(System.getenv(AzureProperties.BLOB_KEY))
//					.containerName(AzureProperties.HOUSE_BLOB_CONTAINER_NAME)
//					.buildClient();
//		}
//		String[] connectionStr = System.getenv("AzureCosmosDBConnection").split(";");
//		String endpoint = connectionStr[0].split("=")[1];
//
//		String key = connectionStr[1].split("=", 2)[1];
//		context.getLogger().info(System.getenv("AzureCosmosDBConnection"));
//		context.getLogger().info(endpoint);
//		context.getLogger().info(key);
//		context.getLogger().info(Arrays.toString(houses));
		try (Jedis jedis = RedisCache.getCachePool().getResource()) {
			jedis.incr("cnt:houses");
			for( String h : houses) {
				jedis.lpush("recent::added::houses", h);
			}
			jedis.ltrim("recent::added::houses", 0, 9);
		}
    }

}
